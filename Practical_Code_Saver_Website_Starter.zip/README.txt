COLLEGE PRACTICAL CODES — STARTER WEBSITE

This folder contains a simple, mobile-friendly website with 15 empty practical slots.
The codes are NOT filled in yet.

IMPORTANT:
- This is a website file, not a live public link yet.
- To open it on a different college PC using a link, it must be published to a hosting service.
- Easiest publishing option: use GitHub Pages (a free GitHub account may be required), or another static hosting service.
- When your friend sends the codes, send them in this chat and we can fill the page in.

File:
- index.html — the website. Open it in a browser to preview locally.

For a quick GitHub Pages publish:
1. Sign in to GitHub and create a new public repository (e.g. practical-codes).
2. Upload index.html to the repository root.
3. In repository Settings > Pages, choose deploy from the main branch/root.
4. Wait for GitHub to show the published site URL.
5. Open that URL on the college PC.

Only publish content you're allowed to share publicly. A public GitHub Pages site can be viewed by anyone who has the link (and potentially discovered publicly).
